package com.cg.capstore.controller;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.validation.constraints.Past;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.capstore.entities.CommonFeedback;
import com.cg.capstore.service.CommonFeedbackServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class CommonFeedbackController {
	@Autowired
	CommonFeedbackServiceImpl capstore_service;
	Logger logger=LoggerFactory.getLogger(CommonFeedbackController.class);
	
	/* 
	 * When /addfeedback is mapped with client request commonFeedbackUser method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@PostMapping("/addfeedback")
	public boolean commonFeedbackUser(@RequestBody CommonFeedback1 common_feedback)
	{
		logger.trace("commonFeedbackUser method is accessed at controller layer");
		CommonFeedback cf=new CommonFeedback();
		cf.setFeedbackSubject(common_feedback.feedbackSubject);
		cf.setFeedbackMessage(common_feedback.feedbackMessage);
		return capstore_service.commonFeedbackUser(common_feedback.username,common_feedback.merchant_name,cf);
	}
	
	/* 
	 * When /getMerchantNameList/{username} is mapped with client request merchantNameList method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("/getMerchantNameList/{username}")
	public Set<String> merchantNameList(@PathVariable String username)
	{
		logger.trace("merchantNameList method is accessed at controller layer");
		return capstore_service.merchantNameList(username);
	}
	
	/* 
	 * When /getFeedbacksMerchant/{m_username} is mapped with client request commonFeedbackMerchant method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("/getFeedbacksMerchant/{m_username}")
	public Set<CommonFeedbackDetailsForMerchant> commonFeedbackMerchant(@PathVariable String m_username){
		logger.trace("commonFeedbackMerchant method is accessed at controller layer");
		 Set<CommonFeedback> feedbackDetailed=new HashSet<CommonFeedback>();
		 Set<CommonFeedbackDetailsForMerchant> feedbackRequired=new HashSet<CommonFeedbackDetailsForMerchant>();
		 feedbackDetailed=capstore_service.commonFeedbackMerchant(m_username);
		 Iterator itr=feedbackDetailed.iterator();
			while(itr.hasNext()) {
				CommonFeedback feedback1=(CommonFeedback)itr.next();
				CommonFeedbackDetailsForMerchant obj=new CommonFeedbackDetailsForMerchant();
				obj.feedbackId=feedback1.getFeedbackId();
				obj.feedbackSubject=feedback1.getFeedbackSubject();
				obj.feedbackMessage=feedback1.getFeedbackMessage();
				feedbackRequired.add(obj);
			}
		return feedbackRequired;
	}
	
	/* 
	 * When /getMerchantResponse is mapped with client request merchantResponse method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@PostMapping("/getMerchantResponse")
	public boolean merchantResponse(@RequestBody merchantResponse1 response1) {
		logger.trace("merchantResponse method is accessed at controller layer");
		return capstore_service.merchantResponse(response1.feedbackId,response1.response);
	}
	
	/* 
	 * When /responseToUser/{username} is mapped with client request responseToUser method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("/responseToUser/{username}")
	public Set<FeedbackDetailsForUSer> responseToUser(@PathVariable String username){
		logger.trace("responseToUser method is accessed at controller layer");
		Set<CommonFeedback> feedbackDetailed=new HashSet<CommonFeedback>();
		Set<FeedbackDetailsForUSer> feedbackRequired=new HashSet<FeedbackDetailsForUSer>();
		feedbackDetailed=capstore_service.responseToUser(username);
		Iterator itr=feedbackDetailed.iterator();
		while(itr.hasNext()) {
			CommonFeedback feedback1=(CommonFeedback)itr.next();
			FeedbackDetailsForUSer obj=new FeedbackDetailsForUSer();
			obj.feedbackId=feedback1.getFeedbackId();
			obj.m_username=feedback1.getMerchant().getUsername();
			obj.feedbackSubject=feedback1.getFeedbackSubject();
			obj.feedbackMessage=feedback1.getFeedbackMessage();
			obj.response=feedback1.getResponse();
			feedbackRequired.add(obj);
			
		}
		return feedbackRequired;
		
	}
	
	/* 
	 * When getMerchantListSize/{username} is mapped with client request mechantNameListNotEmpty method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("getMerchantListSize/{username}")
	public boolean mechantNameListNotEmpty(@PathVariable String username) {
		logger.trace("mechantNameListNotEmpty method is accessed at controller layer");
		return capstore_service.merchantNameListNotEmpty(username);
	}
	
	/* 
	 * When getMerchantFeedbackSize/{m_username} is mapped with client request mechantFeedbackListNotEmpty method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("getMerchantFeedbackSize/{m_username}")
	public boolean mechantFeedbackListNotEmpty(@PathVariable String m_username) {
		logger.trace("mechantFeedbackListNotEmpty method is accessed at controller layer");
		return capstore_service.merchantFeedbackListNotEmpty(m_username);
	}
	
	/* 
	 * When getUserFeedbackSize/{username} is mapped with client request userFeedbackListNotEmpty method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	
	@GetMapping("getUserFeedbackSize/{username}")
	public boolean userFeedbackListNotEmpty(@PathVariable String username) {
		logger.trace("userFeedbackListNotEmpty method is accessed at controller layer");
		return capstore_service.userFeedbacktListNotEmpty(username);
	}

}
class FeedbackDetailsForUSer{
	public int feedbackId;
	public String m_username;
	public String feedbackSubject;
	public String feedbackMessage;
	public String response;
	
}
class CommonFeedback1{
	public String username;
	public String merchant_name;
	public String feedbackSubject;
	public String feedbackMessage;
}
class CommonFeedbackDetailsForMerchant{
	public int feedbackId;
	public String feedbackSubject;
	public String feedbackMessage;
}
class merchantResponse1{
	public int feedbackId;
	public String response;
}
