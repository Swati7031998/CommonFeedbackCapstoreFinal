package com.cg.capstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonFeedbackCapstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonFeedbackCapstoreApplication.class, args);
	}

}
