package com.cg.capstore.exceptions;

public class NoFeedbacksException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public NoFeedbacksException(String message) {
		super(message);
	}
}
