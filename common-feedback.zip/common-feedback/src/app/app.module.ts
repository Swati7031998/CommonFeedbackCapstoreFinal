import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonFeedbackFormComponent } from 'src/app/components/common-feedback-form/common-feedback-form.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MerchantFeedbackHandlerComponent } from './components/merchant-feedback-handler/merchant-feedback-handler.component';
import { UserFeedbackViewComponent } from './components/user-feedback-view/user-feedback-view.component';
import { HomePageComponent } from './components/home-page/home-page.component';

@NgModule({
  declarations: [
    AppComponent,
    CommonFeedbackFormComponent,
    MerchantFeedbackHandlerComponent,
    UserFeedbackViewComponent,
    HomePageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
