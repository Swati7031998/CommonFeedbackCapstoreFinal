import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators, ControlContainer} from '@angular/forms';
import { UserServicesService } from 'src/app/services/user-services.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-common-feedback-form',
  templateUrl: './common-feedback-form.component.html',
  styleUrls: ['./common-feedback-form.component.css']
})
export class CommonFeedbackFormComponent implements OnInit {
  username:String;
  merchants:String[];
  submitted: boolean = false;
  feedbackForm: FormGroup;
  messages:any;
  errormsg:string;
  sizeValid:boolean;
  constructor(private userService:UserServicesService,private formBuilder:FormBuilder,private router:Router) { }

  ngOnInit() {
    this.username="dummyCust";
    // this.username="aa@gmail.com";
    this.feedbackForm = this.formBuilder.group({
      username: [this.username],
      merchant_name:['',Validators.required],
      feedbackSubject:['',Validators.required],
      feedbackMessage:['',Validators.required]
        });
        this.userService.getMerchantList(this.username).subscribe(data => {
          this.merchants = data;
        },
          err => {
            console.log(err.stack);
          });
    
  }

  /* This method will be called when user submits the feedback form  and that form details will be
  passed to service method so that it can be post to server*/
  send()
  {
    this.submitted = true;
    if (this.feedbackForm.invalid) {
      return;
    }
    this.userService.userFeedback(this.feedbackForm.value).subscribe(data => {
      this.messages= data
      alert("Feedback submitted successfully!!We will get back to you");
      this.router.navigate(['']);
    },
      err => {
        console.log(err.stack);
      });
    
  }

}
