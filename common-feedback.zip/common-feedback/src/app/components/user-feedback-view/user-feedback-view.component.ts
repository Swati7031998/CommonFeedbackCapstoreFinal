import { Component, OnInit } from '@angular/core';
import { UserServicesService } from 'src/app/services/user-services.service';
import { CommonFeedback } from 'src/app/models/commonFeedback';
@Component({
  selector: 'app-user-feedback-view',
  templateUrl: './user-feedback-view.component.html',
  styleUrls: ['./user-feedback-view.component.css']
})
export class UserFeedbackViewComponent implements OnInit {
  username:String;
  feedbacks:CommonFeedback[];
  count:number;
  errormsg:string;
  sizeValid: boolean;
  constructor(private userService:UserServicesService) { }

  ngOnInit() {
    this.username="dummyCust";
    // this.username="aa@gmail.com";
    this.userService.userFeedbackView(this.username).subscribe(data => {
      this.feedbacks = data;
      this.count=this.feedbacks.length;
    },
      err => {
        this.errormsg = err.error;
            alert(this.errormsg);
      });
  }

}
