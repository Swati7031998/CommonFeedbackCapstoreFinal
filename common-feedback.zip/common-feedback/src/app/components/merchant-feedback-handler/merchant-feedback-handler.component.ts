import { Component, OnInit } from '@angular/core';
import { UserServicesService } from 'src/app/services/user-services.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonFeedback } from 'src/app/models/commonFeedback';
import {Response} from 'src/app/models/response';

@Component({
  selector: 'app-merchant-feedback-handler',
  templateUrl: './merchant-feedback-handler.component.html',
  styleUrls: ['./merchant-feedback-handler.component.css']
})
export class MerchantFeedbackHandlerComponent implements OnInit {
  m_username: string;

//Declared Respose Type Object here and given  predefined value  as giving error that feedbackid and respnse is undefined
// type
response:Response={feedbackId:9099999,
response:"no respobse"};


  submitted: boolean = false;
  count: number;
  feedbacks: CommonFeedback[];

  messages: any;
  errormsg: string;
  sizeValid: boolean;
  constructor(private userService: UserServicesService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
    this.m_username="harsha98";
    // this.m_username="abc@gmail.com";
        this.userService.merchantFeedbackHandler(this.m_username).subscribe(data => {
          this.feedbacks = data;
          this.count = this.feedbacks.length;
        },
          err => {
            console.log(err.stack);

          });
    
  }

/*This method will be called when response for any feedback will be submitted  by merchant. The response will be pass
to service and there it will be posted to server */
  send(ResponseForm, id:number) {
    this.submitted = true;
    //This is a Response type object 
    this.response.feedbackId=id;
    this.response.response=ResponseForm.response;
    //extracting values from form  here for testing functionality
   let messa=ResponseForm.response;
    
 
    this.userService.merchantResponseHandler(this.response).subscribe(data => {
      this.messages = data;
      alert("Response submitted successfully!!");
      window.location.reload();
    },
      err => {
        console.log(err.stack);
      });

  }



}
