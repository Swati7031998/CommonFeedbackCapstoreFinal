import { Component, OnInit } from '@angular/core';
import { UserServicesService } from 'src/app/services/user-services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  username: String;
  m_username:String;
  sizeValid: boolean;
  errormsg: String;
  constructor(private userService: UserServicesService, private router: Router) { }

  ngOnInit() {
  }

  /* This method will check whether the user has any merchant or not , if has merchant than only route to
  merchant feedback page*/
  feedbackForm() {
    this.username = "dummyCust";
    // this.username="aa@gmail.com";
    this.userService.merchantNameListNotEmpty(this.username).subscribe(data => {
      this.sizeValid = data;
      if (this.sizeValid)
        this.router.navigate(['/app-common-feedback-form'])
    },
      err => {
        this.errormsg = err.error;
        alert(this.errormsg);
      });

  }

   /* This method will check whether the merchant has any feedback or not , if has feedback than only route to
  merchant feedback page*/
  feedbacks() {
    // this.m_username="vamsi586";
    this.m_username="harsha98";
    // this.m_username = "abc@gmail.com";
    this.userService.merchantFeedbackListNotEmpty(this.m_username).subscribe(data => {
      this.sizeValid = data;
      if (this.sizeValid) 
        this.router.navigate(['/app-merchant-feedback-handler']);
    },
     err => {
        this.errormsg = err.error;
        alert(this.errormsg);
      });

  }
   /* This method will check whether the user has any replies of feedback or not , if has feedback reply from merchant
    than only route to view  feedback response page*/
  feedbacksUser() {
    this.username = "dummyCust";
    // this.username="aa@gmail.com";
    this.userService.userFeedbackListNotEmpty(this.username).subscribe(data => {
      this.sizeValid = data;
      if (this.sizeValid) 
        this.router.navigate(['/app-user-feedback-view']);
    },
    err => {
      this.errormsg = err.error;
      alert(this.errormsg);
    });

  }

}
