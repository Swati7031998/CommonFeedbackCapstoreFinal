export class Merchant{
    username:String;
}