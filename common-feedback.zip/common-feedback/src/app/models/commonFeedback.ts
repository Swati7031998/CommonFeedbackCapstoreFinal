
export class CommonFeedback{
feedbackId : number;
feedbackMessage:String;           
feedbackSubject:String; 
m_username:String;
response:String;
}
