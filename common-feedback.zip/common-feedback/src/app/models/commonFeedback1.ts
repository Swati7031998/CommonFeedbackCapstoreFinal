
export class CommonFeedback1{
    username:String;
	merchant_name:String;
    feedbackSubject:String;
    feedbackMessage:String;
}