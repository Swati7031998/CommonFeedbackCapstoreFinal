export class Response{
    feedbackId:number;
    response:String;

}