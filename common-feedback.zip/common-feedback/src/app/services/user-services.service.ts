import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CommonFeedback1 } from '../models/commonFeedback1';
import { CommonFeedback } from '../models/commonFeedback';
import {Response} from '../models/response';


@Injectable({
  providedIn: 'root'
})
export class UserServicesService {

  constructor(private http:HttpClient) { }
  baseUrl: string = "http://localhost:8080/api";
 
  // This method will take a argument username and will fetch the list of merchant who are having username as same
  // and will return it   
  getMerchantList(username: String) {
    return this.http.get<String[]>(this.baseUrl + "/getMerchantNameList/" + username);
  }

  //This method will take a argument of type feedback which will post to server and add it to database    
  userFeedback(feedback:CommonFeedback1){
   return this.http.post(this.baseUrl + "/addfeedback",feedback);
  }
  // This method will take a argument of merchant name and will return a list of feedback send by users to 
  // this merchant 
  merchantFeedbackHandler(m_username:String){
    return this.http.get<CommonFeedback[]>(this.baseUrl + "/getFeedbacksMerchant/"+m_username);
   }

  //This method will take a object of response type which will be response of merchant to 
  // user for their feedback 
   merchantResponseHandler(response:Response)
   {
          return this.http.post(this.baseUrl+"/getMerchantResponse",response);
   }

   // This method will take username as a argument and will fetch the list of response of feedbacks send by 
   // merchants, whom the user had send feedback 
   userFeedbackView(username:String){
     return this.http.get<CommonFeedback[]>(this.baseUrl+"/responseToUser/"+username);
   }

   //This method will take username as a arguments and will return true or false based on condition that
   // whether the merchant list in database is empty or not
   merchantNameListNotEmpty(username:String){
    return this.http.get<boolean>(this.baseUrl + "/getMerchantListSize/" + username).pipe(catchError(this.handleError));
   }

   //This method will take merchant name as a argument and will return true or false based on condition
   // that whether merchant has recieved any feedbacks or not
   merchantFeedbackListNotEmpty(m_username:String){
    return this.http.get<boolean>(this.baseUrl + "/getMerchantFeedbackSize/"+m_username).pipe(catchError(this.handleError));
   }

   //This method will take a username as argument and will return true or false based on condition that whether that
   // the user has recieved any reply for the feedbacks he gave or not
   userFeedbackListNotEmpty(username:String){
    return this.http.get<boolean>(this.baseUrl+"/getUserFeedbackSize/"+username).pipe(catchError(this.handleError));
  }

  /*
  This  method is used to handle the exceptions that might be received
  */
  private handleError(errorResponse: HttpErrorResponse) {
    return throwError(errorResponse);
  }
}
