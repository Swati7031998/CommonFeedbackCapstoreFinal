import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonFeedbackFormComponent } from './components/common-feedback-form/common-feedback-form.component';
import { MerchantFeedbackHandlerComponent } from './components/merchant-feedback-handler/merchant-feedback-handler.component';
import { UserFeedbackViewComponent } from './components/user-feedback-view/user-feedback-view.component';
import { HomePageComponent } from './components/home-page/home-page.component';


const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'app-home-page',component:HomePageComponent},
  {path:'app-common-feedback-form',component:CommonFeedbackFormComponent},
  {path:'app-merchant-feedback-handler',component:MerchantFeedbackHandlerComponent},
  {path:'app-user-feedback-view',component:UserFeedbackViewComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
